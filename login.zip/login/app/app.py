from flask import Flask, render_template, request
from sqlalchemy import create_engine
import pyodbc

# Conexión a la base de datos de SQL Server
server = 'Daniel\SQLEXPRESS'
database = 'sherleg'
username = 'daniel_1'
password = '12345'
driver= '{SQL Server}'
cnxn = pyodbc.connect(f'DRIVER={driver};SERVER={server};DATABASE={database};UID={username};PWD={password}')
cursor = cnxn.cursor()


# Crear la aplicación de Flask
app = Flask(__name__)

# Ruta para agregar registros
@app.route('/agregar', methods=['GET', 'POST'])
def agregar():
    if request.method == 'POST':
        # Obtener el nombre del formulario
        nombre = request.form['nombre']
        # Agregar el registro a la base de datos
        cursor.execute("INSERT INTO registros (FECHA, TIPO, COMPROBANTE, NUMERO, NIT, SUCURSAL, NOMBRE_TERCERO, VALOR) VALUES (?,?,?,?,?,?,?,?)", nombre)
        cnxn.commit()
        return 'Registro agregado'
    else:
        return render_template('agregar.html')

# Ejecutar la aplicación de Flask
if __name__ == '__main__':
    app.run()



























































"""from flask import Flask, render_template, request, redirect
import pyodbc

app = Flask(__name__)

# Configuración de la conexión a la base de datos
server = 'Daniel\SQLEXPRESS'
database = 'sherleg'
username = 'daniel_1'
password = '12345'
driver = '{ODBC Driver 17 for SQL Server}'

# Función para verificar las credenciales del usuario
def verificar_credenciales(userna, passwo):
    conn = pyodbc.connect('DRIVER=' + driver + ';SERVER=' + server + ';PORT=1433;DATABASE=' + database + ';UID=' + username + ';PWD=' + password)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM usuarios WHERE username = ? AND password = ?", (userna, passwo))
    resultado = cursor.fetchone()
    conn.close()
    return resultado[0] == 1

print("vamos bien")

# Ruta para la página de inicio
@app.route('/')
def inicio():
    return render_template('inicio.html')

# Ruta para el login
@app.route('/login', methods=['POST'])
def login():
    username_login = request.form['username']
    password_login = request.form['password']
    if verificar_credenciales(username_login, password_login):
        return redirect('/dashboard')
    else:
        mensaje = 'Credenciales inválidas.'
        return render_template('inicio.html', mensaje=mensaje)

# Ruta para el dashboard
@app.route('/dashboard')
def mostrar_datos():
    conn = pyodbc.connect('DRIVER=' + driver + ';SERVER=' + server + ';PORT=1433;DATABASE=' + database + ';UID=' + username + ';PWD=' + password)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Clientes$')
    print("vamos bien")
    rows = cursor.fetchall()
    return render_template('dashboard.html', datos=rows)

if __name__ == '__main__':
    app.run(debug=True)"""